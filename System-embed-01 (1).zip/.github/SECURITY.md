# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| v0.0.2 | :white_check_mark: |


## Reporting a Vulnerability

Hi Guys, If you find any Vulnerability in the code please go to Issues and make a bug issue for that we will fix it as soon as possible.
